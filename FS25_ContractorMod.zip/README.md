First alpha version converted for FS25.  
A lot of missing features but this is a start.  
Working ad of today:  
 - Create new game with 4 characters
 - Switch between characters instead of vehicles
 - Only characters in vehicle remains visible (not characters on foot)
 - Save game and reload
 - Characters names can be changed in xml savegame
