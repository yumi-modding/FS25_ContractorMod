--[[
	Auto Start Savegame Mod
	Automatically starts a savegame when autoStartSavegameId parameter is set
]]--

local AutoStartSavegameMod = {}
AutoStartSavegameMod.isInitialized = false
AutoStartSavegameMod.checkTimer = 0
AutoStartSavegameMod.careerScreenProcessed = false

-- Actual auto-start logic
function AutoStartSavegameMod:autoStartSavegame(savegameId)
	if g_careerScreen == nil then
		print("[AutoStartSavegame] Error: g_careerScreen is not available")
		return
	end
	
	print("[AutoStartSavegame] Setting selected savegame index to: " .. savegameId)
	g_careerScreen:setSelectedSavegameIndex(savegameId)
	
	-- Get the savegame
	local savegame = g_savegameController:getSavegame(savegameId)
	
	-- Check if savegame is valid
	if savegame == SavegameController.NO_SAVEGAME then
		print("[AutoStartSavegame] Error: Savegame " .. savegameId .. " is not found")
		return
	end
	
	if not savegame.isValid then
		print("[AutoStartSavegame] Error: Savegame " .. savegameId .. " is not valid")
		return
	end
	
	print("[AutoStartSavegame] Savegame is valid, starting game...")
	g_careerScreen.currentSavegame = savegame
	g_careerScreen:startCurrentSavegame()
	print("[AutoStartSavegame] Game started!")
end

-- Handle savegames loaded message
function AutoStartSavegameMod:onSavegamesLoaded(savegameId)
	print("[AutoStartSavegame] SAVEGAMES_LOADED event triggered")
	self:autoStartSavegame(savegameId)
end

-- Check when CareerScreen is displayed
function AutoStartSavegameMod:checkAndAutoStart()
	local autoStartSavegameId = StartParams.getValue("autoStartSavegameId")
	
	if autoStartSavegameId == nil then
		return
	end
	
	if g_gui == nil or g_gui.currentGuiName ~= "CareerScreen" then
		return
	end
	
	if g_careerScreen == nil then
		return
	end
	
	local savegameId = tonumber(autoStartSavegameId)
	if savegameId == nil then
		return
	end
	
	print("[AutoStartSavegame] CareerScreen detected with autoStartSavegameId: " .. savegameId)
	
	-- Check if savegames are still loading
	if g_savegameController:getIsWaitingForSavegameInfo() then
		print("[AutoStartSavegame] Savegames are still loading, subscribing to SAVEGAMES_LOADED event")
		g_messageCenter:subscribeOneshot(MessageType.SAVEGAMES_LOADED, self.onSavegamesLoaded, self, savegameId)
	else
		print("[AutoStartSavegame] Savegames are ready, starting immediately")
		self:autoStartSavegame(savegameId)
	end
	
	-- Mark as processed so we don't try again
	self.careerScreenProcessed = true
end

-- Initialize the mod
function AutoStartSavegameMod:init()
	if not self.isInitialized then
		print("[AutoStartSavegame] Initializing mod...")
		self.isInitialized = true
		print("[AutoStartSavegame] Mod initialized!")
	end
end

-- Update function to check on every frame
function AutoStartSavegameMod:update(dt)
	print("[AutoStartSavegame] Update called, dt: " .. tostring(dt))
	if not self.careerScreenProcessed then
		self.checkTimer = self.checkTimer + dt
		if self.checkTimer >= 100 then
			self.checkTimer = 0
			self:checkAndAutoStart()
		end
	end
end

-- Initialize when the mod is loaded
AutoStartSavegameMod:init()

-- Register update function by wrapping the existing update
local originalUpdate = update or function() end

function update(dt)
	AutoStartSavegameMod:update(dt)
	originalUpdate(dt)
end

print("[AutoStartSavegame] Mod loaded successfully")

addModEventListener(AutoStartSavegameMod)